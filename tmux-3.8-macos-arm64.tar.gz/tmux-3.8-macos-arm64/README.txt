tmux 3.8 portable pour macOS 15+ Apple Silicon (ARM64).
Lancer bin/tmux depuis le dossier extrait. Aucun brew install nécessaire.
Conserver le dossier entier : bin, libexec, lib et share sont nécessaires.
Bibliothèques issues des bouteilles Homebrew, chemins relocalisés et signature ad hoc.
Ce paquet n'est pas notarisé par Apple. Licences dans licenses/.
